"""Redis cache for answers to repeated questions.

If Redis is not reachable the app keeps working, just without caching.
"""
import hashlib
import json
import logging

import redis

from .config import get_settings

log = logging.getLogger(__name__)


class AnswerCache:
    def __init__(self, url: str, ttl: int):
        self.ttl = ttl
        self.client = None
        try:
            client = redis.Redis.from_url(url, decode_responses=True, socket_timeout=2)
            client.ping()
            self.client = client
            log.info("Connected to Redis")
        except Exception:
            log.warning("Redis unavailable, caching disabled")

    @staticmethod
    def _key(question: str) -> str:
        normalized = " ".join(question.lower().split())
        return "answer:" + hashlib.sha256(normalized.encode()).hexdigest()

    def get(self, question: str):
        if not self.client:
            return None
        try:
            raw = self.client.get(self._key(question))
            return json.loads(raw) if raw else None
        except Exception:
            return None

    def set(self, question: str, value: dict) -> None:
        if not self.client:
            return
        try:
            self.client.setex(self._key(question), self.ttl, json.dumps(value))
        except Exception:
            pass

    def clear(self) -> None:
        if not self.client:
            return
        for key in self.client.scan_iter("answer:*"):
            self.client.delete(key)


_cache = None


def get_cache() -> AnswerCache:
    global _cache
    if _cache is None:
        s = get_settings()
        _cache = AnswerCache(s.redis_url, s.cache_ttl_seconds)
    return _cache
