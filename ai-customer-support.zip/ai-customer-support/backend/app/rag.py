"""Retrieval-Augmented Generation: ingest documents into Pinecone and answer questions."""
import logging
import tempfile
from pathlib import Path
from typing import AsyncIterator

from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pinecone import Pinecone, ServerlessSpec

from .config import get_settings

log = logging.getLogger(__name__)

SUPPORTED_TYPES = {".pdf", ".txt", ".md"}

PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a friendly, concise customer support assistant. "
            "Answer ONLY using the context below. If the answer is not in the context, "
            "say you don't know and suggest contacting a human agent. "
            "Never make up policies, prices or dates.\n\nContext:\n{context}",
        ),
        ("human", "{question}"),
    ]
)


def split_documents(docs: list[Document]) -> list[Document]:
    s = get_settings()
    splitter = RecursiveCharacterTextSplitter(chunk_size=s.chunk_size, chunk_overlap=s.chunk_overlap)
    return splitter.split_documents(docs)


def format_context(docs: list[Document]) -> str:
    return "\n\n".join(f"[Source: {d.metadata.get('source', 'unknown')}]\n{d.page_content}" for d in docs)


def unique_sources(docs: list[Document]) -> list[str]:
    seen: list[str] = []
    for d in docs:
        src = d.metadata.get("source", "unknown")
        if src not in seen:
            seen.append(src)
    return seen


class RAGService:
    def __init__(self):
        s = get_settings()
        self.settings = s
        self.embeddings = OpenAIEmbeddings(model=s.embedding_model, api_key=s.openai_api_key)
        self.llm = ChatOpenAI(model=s.chat_model, api_key=s.openai_api_key, temperature=0.1, streaming=True)
        pc = Pinecone(api_key=s.pinecone_api_key)
        if s.pinecone_index not in pc.list_indexes().names():
            log.info("Creating Pinecone index %s", s.pinecone_index)
            pc.create_index(
                name=s.pinecone_index,
                dimension=s.embedding_dim,
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            )
        self.store = PineconeVectorStore(index=pc.Index(s.pinecone_index), embedding=self.embeddings)

    def ingest_file(self, filename: str, content: bytes) -> int:
        suffix = Path(filename).suffix.lower()
        if suffix not in SUPPORTED_TYPES:
            raise ValueError(f"Unsupported file type {suffix}. Use PDF, TXT or MD.")
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(content)
            path = tmp.name
        try:
            loader = PyPDFLoader(path) if suffix == ".pdf" else TextLoader(path, encoding="utf-8")
            docs = loader.load()
        finally:
            Path(path).unlink(missing_ok=True)
        for d in docs:
            d.metadata["source"] = filename
        chunks = split_documents(docs)
        self.store.add_documents(chunks)
        log.info("Ingested %s as %d chunks", filename, len(chunks))
        return len(chunks)

    def retrieve(self, question: str) -> list[Document]:
        return self.store.similarity_search(question, k=self.settings.top_k)

    async def stream_answer(self, question: str, docs: list[Document]) -> AsyncIterator[str]:
        messages = PROMPT.format_messages(context=format_context(docs), question=question)
        async for chunk in self.llm.astream(messages):
            if chunk.content:
                yield chunk.content


_rag = None


def get_rag() -> RAGService:
    global _rag
    if _rag is None:
        _rag = RAGService()
    return _rag
