"""FastAPI app: document upload, real-time chat over WebSockets, health and metrics."""
import logging
import time

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from .cache import AnswerCache, get_cache
from .rag import RAGService, get_rag, unique_sources

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("support")

app = FastAPI(title="AI Customer Support API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MAX_UPLOAD_BYTES = 10 * 1024 * 1024
stats = {"questions": 0, "cache_hits": 0, "total_latency_ms": 0.0, "active_connections": 0}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/metrics")
def metrics():
    q = stats["questions"]
    return {
        **stats,
        "avg_latency_ms": round(stats["total_latency_ms"] / q, 1) if q else 0,
        "cache_hit_rate": round(stats["cache_hits"] / q, 3) if q else 0,
    }


@app.post("/documents")
async def upload_document(
    file: UploadFile = File(...),
    rag: RAGService = Depends(get_rag),
    cache: AnswerCache = Depends(get_cache),
):
    content = await file.read()
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "File too large (max 10 MB)")
    try:
        chunks = rag.ingest_file(file.filename or "upload.txt", content)
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear()  # new knowledge may change answers
    return {"filename": file.filename, "chunks": chunks}


@app.websocket("/ws/chat")
async def chat(ws: WebSocket):
    """Protocol: client sends {"question": "..."}; server streams
    {"type":"token","content":...} messages, then {"type":"done","sources":[...],"cached":bool,"latency_ms":n}."""
    await ws.accept()
    stats["active_connections"] += 1
    rag = get_rag()
    cache = get_cache()
    try:
        while True:
            data = await ws.receive_json()
            question = (data.get("question") or "").strip()
            if not question:
                await ws.send_json({"type": "error", "content": "Please type a question."})
                continue
            start = time.perf_counter()
            stats["questions"] += 1

            cached = cache.get(question)
            if cached:
                stats["cache_hits"] += 1
                await ws.send_json({"type": "token", "content": cached["answer"]})
                sources, from_cache = cached["sources"], True
            else:
                docs = rag.retrieve(question)
                sources = unique_sources(docs)
                parts = []
                async for token in rag.stream_answer(question, docs):
                    parts.append(token)
                    await ws.send_json({"type": "token", "content": token})
                cache.set(question, {"answer": "".join(parts), "sources": sources})
                from_cache = False

            latency = (time.perf_counter() - start) * 1000
            stats["total_latency_ms"] += latency
            await ws.send_json(
                {"type": "done", "sources": sources, "cached": from_cache, "latency_ms": round(latency)}
            )
    except WebSocketDisconnect:
        pass
    except Exception:
        log.exception("Chat error")
        try:
            await ws.send_json({"type": "error", "content": "Something went wrong. Please try again."})
        except Exception:
            pass
    finally:
        stats["active_connections"] -= 1
