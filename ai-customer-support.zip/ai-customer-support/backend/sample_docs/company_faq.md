# ShopEase Customer Support FAQ

## Shipping
- Standard shipping takes 5–7 business days and is free on orders over $50.
- Express shipping takes 1–2 business days and costs $15.
- We ship to all 50 US states. International shipping is not available yet.

## Returns and Refunds
- Items can be returned within 30 days of delivery if unused and in original packaging.
- Refunds are issued to the original payment method within 5–10 business days after we receive the item.
- Sale items marked "Final Sale" cannot be returned.

## Orders
- You can cancel an order within 2 hours of placing it from the "My Orders" page.
- To track an order, use the tracking link in your confirmation email.

## Account
- To reset your password, click "Forgot password" on the login page.
- Support hours: Monday to Friday, 9 AM – 6 PM Central Time. Email: support@shopease.example
