"""Tests run without OpenAI, Pinecone or Redis by swapping in fakes."""
from fastapi.testclient import TestClient
from langchain_core.documents import Document

from app.cache import AnswerCache
from app.main import app
from app.rag import get_rag, split_documents, unique_sources
from app.cache import get_cache


class FakeRAG:
    def __init__(self):
        self.ingested = []

    def ingest_file(self, filename, content):
        if not filename.endswith((".txt", ".md", ".pdf")):
            raise ValueError("Unsupported file type")
        self.ingested.append(filename)
        return 3

    def retrieve(self, question):
        return [Document(page_content="Refunds within 30 days.", metadata={"source": "faq.md"})]

    async def stream_answer(self, question, docs):
        for word in ["You ", "can ", "get ", "a ", "refund."]:
            yield word


class FakeCache(AnswerCache):
    def __init__(self):
        self.ttl, self.client, self.data = 60, None, {}

    def get(self, q):
        return self.data.get(self._key(q))

    def set(self, q, v):
        self.data[self._key(q)] = v

    def clear(self):
        self.data.clear()


fake_rag, fake_cache = FakeRAG(), FakeCache()
app.dependency_overrides[get_rag] = lambda: fake_rag
app.dependency_overrides[get_cache] = lambda: fake_cache

import app.main as main_module  # noqa: E402

main_module.get_rag = lambda: fake_rag
main_module.get_cache = lambda: fake_cache
client = TestClient(app)


def test_health():
    assert client.get("/health").json() == {"status": "ok"}


def test_upload_and_reject_bad_type():
    r = client.post("/documents", files={"file": ("faq.md", b"# FAQ", "text/markdown")})
    assert r.status_code == 200 and r.json()["chunks"] == 3
    r = client.post("/documents", files={"file": ("virus.exe", b"x", "application/octet-stream")})
    assert r.status_code == 400


def test_chat_streams_then_caches():
    with client.websocket_connect("/ws/chat") as ws:
        ws.send_json({"question": "Can I get a refund?"})
        tokens = []
        while True:
            msg = ws.receive_json()
            if msg["type"] == "done":
                break
            tokens.append(msg["content"])
        assert "".join(tokens) == "You can get a refund."
        assert msg["sources"] == ["faq.md"] and msg["cached"] is False

        ws.send_json({"question": "can i get a   REFUND?"})
        ws.receive_json()
        done = ws.receive_json()
        assert done["cached"] is True


def test_helpers():
    docs = split_documents([Document(page_content="word " * 1000, metadata={"source": "a"})])
    assert len(docs) > 1
    assert unique_sources(docs) == ["a"]
