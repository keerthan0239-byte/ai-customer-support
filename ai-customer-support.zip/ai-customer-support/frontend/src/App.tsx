import { FormEvent, useEffect, useRef, useState } from "react";
import { uploadDocument } from "./api";
import { useChat } from "./useChat";

export default function App() {
  const { messages, connected, busy, send } = useChat();
  const [input, setInput] = useState("");
  const [uploadStatus, setUploadStatus] = useState("");
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    send(input);
    setInput("");
  };

  const onUpload = async (file?: File) => {
    if (!file) return;
    setUploadStatus(`Uploading ${file.name}...`);
    try {
      const r = await uploadDocument(file);
      setUploadStatus(`Added ${r.filename} (${r.chunks} chunks)`);
    } catch (err) {
      setUploadStatus((err as Error).message);
    }
  };

  return (
    <div className="app">
      <header>
        <div>
          <h1>AI Customer Support</h1>
          <span className={connected ? "status on" : "status off"}>{connected ? "Online" : "Reconnecting..."}</span>
        </div>
        <label className="upload">
          Upload knowledge (PDF/TXT/MD)
          <input type="file" accept=".pdf,.txt,.md" onChange={(e) => onUpload(e.target.files?.[0])} hidden />
        </label>
      </header>
      {uploadStatus && <p className="upload-status">{uploadStatus}</p>}

      <main className="chat">
        {messages.length === 0 && <p className="empty">Ask anything about shipping, returns, orders or your account.</p>}
        {messages.map((m, i) => (
          <div key={i} className={`bubble ${m.role}`}>
            <p>{m.content || (busy && i === messages.length - 1 ? "Typing..." : "")}</p>
            {m.sources && m.sources.length > 0 && (
              <small>
                Sources: {m.sources.join(", ")} · {m.latencyMs} ms{m.cached ? " · cached" : ""}
              </small>
            )}
          </div>
        ))}
        <div ref={bottom} />
      </main>

      <form onSubmit={onSubmit}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type your question..." disabled={!connected} />
        <button disabled={!connected || busy || !input.trim()}>Send</button>
      </form>
    </div>
  );
}
