import { useCallback, useEffect, useRef, useState } from "react";
import { WS_URL } from "./api";

export type Message = {
  role: "user" | "assistant";
  content: string;
  sources?: string[];
  cached?: boolean;
  latencyMs?: number;
};

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [connected, setConnected] = useState(false);
  const [busy, setBusy] = useState(false);
  const ws = useRef<WebSocket | null>(null);

  useEffect(() => {
    let retry: number | undefined;
    const connect = () => {
      const socket = new WebSocket(WS_URL);
      ws.current = socket;
      socket.onopen = () => setConnected(true);
      socket.onclose = () => {
        setConnected(false);
        setBusy(false);
        retry = window.setTimeout(connect, 2000); // auto-reconnect
      };
      socket.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        setMessages((prev) => {
          const next = [...prev];
          const last = next[next.length - 1];
          if (msg.type === "token" && last?.role === "assistant") {
            next[next.length - 1] = { ...last, content: last.content + msg.content };
          } else if (msg.type === "done" && last?.role === "assistant") {
            next[next.length - 1] = { ...last, sources: msg.sources, cached: msg.cached, latencyMs: msg.latency_ms };
          } else if (msg.type === "error") {
            next.push({ role: "assistant", content: msg.content });
          }
          return next;
        });
        if (msg.type === "done" || msg.type === "error") setBusy(false);
      };
    };
    connect();
    return () => {
      window.clearTimeout(retry);
      if (ws.current) {
        ws.current.onclose = null;
        ws.current.close();
      }
    };
  }, []);

  const send = useCallback((question: string) => {
    if (!ws.current || ws.current.readyState !== WebSocket.OPEN || !question.trim()) return;
    setMessages((prev) => [...prev, { role: "user", content: question }, { role: "assistant", content: "" }]);
    setBusy(true);
    ws.current.send(JSON.stringify({ question }));
  }, []);

  return { messages, connected, busy, send };
}
