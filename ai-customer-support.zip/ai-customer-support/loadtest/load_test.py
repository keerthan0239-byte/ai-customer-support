"""Simple WebSocket load test.

Opens N concurrent chat connections, each asking questions, and reports latency.
Usage:  pip install websockets
        python loadtest/load_test.py --users 100 --questions 3
"""
import argparse
import asyncio
import json
import random
import statistics
import time

import websockets

QUESTIONS = [
    "How long does standard shipping take?",
    "Can I return a sale item?",
    "How do I reset my password?",
    "When will I get my refund?",
    "Do you ship internationally?",
    "How can I cancel my order?",
]


async def user(url: str, n: int, latencies: list, errors: list):
    try:
        async with websockets.connect(url, open_timeout=20) as ws:
            for _ in range(n):
                start = time.perf_counter()
                await ws.send(json.dumps({"question": random.choice(QUESTIONS)}))
                while True:
                    msg = json.loads(await ws.recv())
                    if msg["type"] in ("done", "error"):
                        break
                latencies.append((time.perf_counter() - start) * 1000)
    except Exception as e:
        errors.append(str(e))


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", default="ws://localhost:8000/ws/chat")
    p.add_argument("--users", type=int, default=50)
    p.add_argument("--questions", type=int, default=3)
    a = p.parse_args()

    latencies, errors = [], []
    start = time.perf_counter()
    await asyncio.gather(*(user(a.url, a.questions, latencies, errors) for _ in range(a.users)))
    total = time.perf_counter() - start

    print(f"Concurrent users:   {a.users}")
    print(f"Answers received:   {len(latencies)}   Errors: {len(errors)}")
    if latencies:
        lat = sorted(latencies)
        print(f"Average latency:    {statistics.mean(lat):.0f} ms")
        print(f"p95 latency:        {lat[int(len(lat) * 0.95) - 1]:.0f} ms")
        print(f"Throughput:         {len(lat) / total:.1f} answers/sec")


if __name__ == "__main__":
    asyncio.run(main())
